# Lab02


[Lab 2 Group 3 WRSPM analysis Daniel Nemov.pdf](https://github.com/ZonDizzler/Lab02/files/9595632/Lab.2.Group.3.WRSPM.analysis.Daniel.Nemov.pdf)
